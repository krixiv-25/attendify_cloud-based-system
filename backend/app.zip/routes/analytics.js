const express = require('express');
const router = express.Router();
const controller = require('../controllers/analyticsController');

router.get('/overview', controller.getOverviewAnalytics);

module.exports = router;