require('dotenv').config();
const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');

const app = express();
app.use(cors());
app.use(cookieParser());

const googleRoutes = require('./routes/google');
app.use('/api/google', googleRoutes);

const analyticsRoutes = require('./routes/analytics');
app.use('/api/analytics', analyticsRoutes);

app.listen(5000, () => console.log('Backend running on port 5000'));