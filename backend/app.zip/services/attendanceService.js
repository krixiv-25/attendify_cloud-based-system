const admin = require('firebase-admin');
const db = admin.firestore();

exports.getAllUsers = async () => {
  const snapshot = await db.collection('users').get();
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

exports.getAttendanceForDate = async (date) => {
  const snapshot = await db.collection('attendance_logs')
    .where('date', '==', date)
    .get();
    
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};